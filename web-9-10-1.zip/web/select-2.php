<?php
include 'header.php';


?>

            <!-- body -->
             <!-- body -->
             <div id="body">
                <!-- left -->
                  <div id="body-left">
                    
                  
                  <table >  
                        <tr>
                          <td class="bg-dark text-center"><a class="nav-link text-light bold" href="select-1.php">Sơ mi</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold" href="select-2.php">Thun</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold" href="select-3.php">Jean</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold" href="select-4.php">Quần short</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold" href="select-5.php">Quần tây</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold" href="select-6.php">Áo khoác</a></td>
                        </tr>
                      </table>
                      
                      <a style="margin-top: 10px;" href="order.php"><img style="width: 200px; height: 110px;" src="image/cart-icon.png" alt=""></a>
                </div>
                  <!-- right -->
                  <div id="body-right">
                    
                 

                    <!-- product -->
                  <?php 
				  $get_data = get("http://35.219.60.232/api.php/loaisps/2/sanphams");
					$data= json_decode($get_data, true);
					foreach($data as $i){
						echo ' <div id="product">
						<div >

						  <a href="product-info.php?id='.$i['idsanpham'].'">

							<img src="'.$i['hinhanh'].'" id="product-image"alt="">
						 
						  </a>
						</div>

						<div id="product-name-div">
						  <a id="product-name" href="product-info.php?id='.$i['idsanpham'].'">
							<h5 style="color:black ;" >

							  '.$i['tensp'].'

							</h5>
						  </a>
					  
						</div>
						<div>
						  <img id="product-icon" src="image/new.png" alt="">
						</div>
						<div id="price">                     

						'.$i['dongia'].' vnđ

						</div>
					  </div>';
								
					}
					?>

                   
                
                    
                  </div>
              </div>
              
              <!-- footer -->
            <div >
              
                <img id="footer" src="image/footer.jpg" alt="">
              </div>
  
        </div>
    </body>
</html>