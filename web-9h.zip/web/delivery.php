<?php
include 'header.php';
?>

            <!-- body -->
             <!-- body -->
             <div id="body">
                 <br>
                <!-- introduce-nav -->
                <div id="introduce-nav">
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src="image/xe.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href="delivery.php"><h5 style="color:black">Giao hàng toàn quốc</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src="image/money.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href="pay.php"><h5 style="color:black">Thanh toán khi nhận hàng</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src="image/tra.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a  href="return.php"><h5 style="color:black">Đổi trả trong vòng 7 ngày</h5></a>
                        </div>
                    </div>
                </div>

                <!-- Nội dung -->
                <div>
                    <div>
                       <br>
                        <h4>PHƯƠNG THỨC GIAO HÀNG VÀ PHÍ VẬN CHUYỂN</h4>
                        <br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>1. Phương thức giao hàng&nbsp;</strong><br>
                            - Shop giao hàng và thanh toán tận nơi trên phạm vi toàn quốc ( Nhận hàng mới thanh toán tiền ).
                            <br><br>
                            - Sau khi bạn đặt hàng, trong vòng 24 giờ chúng tôi sẽ liên lạc lại để kiểm tra thông tin và thỏa thuận thêm những điều khoản khác có liên quan.
                            <br><br>
                            - Một số trường hợp đặc biệt như giá trị đơn hàng quá lớn & thời gian giao hàng vào buổi tối, địa chỉ giao hàng trong ngõ hoặc có thể dẫn đến nguy hiểm. Chúng tôi sẽ chủ động liên lạc với quý khách để thống nhất lại thời gian giao hàng cụ thể.
                            <br><br>
                            - Trong trường hợp giao hàng chậm trễ mà không báo trước, quý khách có thể từ chối nhận hàng và chúng tôi sẽ hoàn trả toàn bộ số tiền mà quý khách trả trước (nếu có) trong vòng 7 ngày.
                            <br><br>
                            - Cam kết tất cả hàng hóa gởi đến quý khách đều là hàng chuẩn form dáng 100% mang thương hiệu độc quyền.
                        
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>2. Phí vận chuyển&nbsp;</strong><br>
                            <b>A. Miễn phí vận chuyển cho các đơn hàng:</b>
                            <br><br>
                            - Dùng phương thức chuyển khoản trước
                            <br><br>
                            - Khi khách hàng mua từ 2 sản phẩm trở lên
                            <br><br>
                            <b>B. Phí vận chuyển nội thành Hà Nội Và Tp.HCM</b>
                            <br><br>
                            TP.HCM: 15.000đ - đơn hàng
                            <br><br>
                            Hà Nội: 15.000đ - Đơn hàng
                            <br><br>
                           <b> C. Khách hàng ở tỉnh:</b>
                            <br><br>
                            Ship chanh ( Từ 3-5 ngày): 35.000đ Giao hàng và thanh toán tận nơi.
                            <br><br>
                            Ship chậm ( Từ 7 - 9 ngày): 20.000đ.
                        
                        </span>
                        <br><br>
                        <hr><hr>

                    </div>
                </div>

            </div>  
              <!-- footer -->
            <div >
                <img id="footer" src="image/footer.jpg" alt="">
                
            </div>
  
        </div>
    </body>
</html>