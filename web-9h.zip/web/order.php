<?php
include 'header.php';
?>


            <?php if( isset($_SESSION['profile'])) : ?>
                        
                      

            <!-- body -->
             <!-- body -->
             <div id="body">
                <div id="order">
                    <div id="order-left">
                        <input class="form-group form-control"  placeholder="Họ và tên" type="text">
                        <input class="form-group form-control"  placeholder="Số điện thoại" type="number">
                        <input class="form-group form-control"  placeholder="Địa chỉ" type="text">
                        <textarea class="form-group form-control" placeholder="Ghi chú" name="" id="" cols="80" rows="5"></textarea>
                        <div  class="form-group form-control">
                            <input   type="radio" id="male" name="thanhtoan" value="01">
                            <label style="margin-right: 10px;" for="01">Thanh toán khi nhận hàng</label>
                            <input type="radio" id="female" name="thanhtoan" value="02">                            
                            <label for="02">chuyển khoản trước</label>
                        </div>
                    </div>
                    <div id="order-right">
                      
                    </div>
                     <button class="btn btn-dark" id="confirm">Đặt hàng</button>
                </div>
               
              </div>
            <?php else: ?>
            <div style="height:700px;padding-top:200px;text-align:center;">
                <div  style="height:100px;border: 5px dashed black; border-radius: 100px;text-align:center;padding-top:18px">
                    <h1 style="color:red;">Vui lòng <a id="login-order" style=" text-decoration: none;" href="login.php">đăng nhập</a> trước khi sử dụng tính năng này</h1>
                </div>
                
            </div>
                
            <?php endif; ?>
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>
    </body>
</html>