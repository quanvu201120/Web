<?php
include 'header.php';
?>

<?php if( isset($_SESSION['profile'])) : ?>
            <!-- body -->
             <!-- body -->
             <div id="body">
                    <h2 align="center" style="color:red">Lịch sử đơn hàng</h2>
                    <div style="width:1000px; height:50px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:150px; height:50px;display:inline-block;float:left">Mã đơn hàng</div>

                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:280px; height:50px;display:inline-block;float:left">Thời gian đặt hàng</div>

                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:300px; height:50px;display:inline-block;float:left">Địa điểm giao</div>

                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:251px; height:50px;display:inline-block;float:left">Tổng tiền</div>

                    </div>
                    <div style=" overflow-y:scroll;width:1000px; max-height:500px; min-height:499px; margin-left:auto; margin-right:auto; margin-bottom:200px">
                          
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                        <!-- item -->
                        <div style="width:1000px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:50px;display:inline-block;float:left">1</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:280px; min-height:50px;display:inline-block;float:left">2020-10-08 15:24:01</div>

                            <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:300px; min-height:50px;display:inline-block;float:left">Quận 10, Tp HCM</div>

                            <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:50px;display:inline-block;float:left">800000 vnđ</div>

                        </div>
                        <!-- End item --> 
                           

                    </div>

            <?php else: ?>
                    <div style="height:700px;padding-top:200px;text-align:center;">
                        <div  style="height:100px;border: 5px dashed black; border-radius: 100px;text-align:center;padding-top:18px">
                            <h1 style="color:red;">Vui lòng <a id="login-order" style=" text-decoration: none;" href="login.php">đăng nhập</a> trước khi sử dụng tính năng này</h1>
                        </div>
                        
                    </div>
                
            <?php endif; ?>                    
              <!-- footer -->
            <div >
                <img id="footer" src=" image/footer.jpg" alt="">
                
            </div>
  
        </div>
    </body>
</html>