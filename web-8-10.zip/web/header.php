<?php
      session_start();
      include_once("call_api.php");


      if(isset($_POST['search'])){
        $search = $_POST['search'];
        $_SESSION['timkiem']=$_POST;
        
        if(!empty($search)){ 
          header('location: search.php');
        }
      }
      
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src=" https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.js"></script>
    </head>
    <style>

          #login-order:hover{
            color: rgb(153, 255, 0);
            font-size: 41px;

          }
           
          #btn-mua{
            
            width:500px;
            height:50px ; 
            margin-top:10px;
            margin-left:75px

          }
         
          label.error {
            color: red;
          }

          .ck-editor__editable_inline {
              min-height: 200px;
          }
            #content{
              
              width: 600px;
              height: 160px;
              word-wrap: break-word;
          
          }
          #content p{
            font-size: 20px;
          
          }
          #content-text {
            margin-left:10px ;
          }
          #div-size{
          height: 40px;
          width: 600px;
          
          
        }   
        #content-color{
          color: rgb(16, 134, 238);
          display: inline-block;
        }
        .color-text{
          color: rgb(16, 134, 238);
        }

    </style>
    <body>
       
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
            <?php if( isset($_SESSION['profile'])) : ?>
    
              <a style="margin-right: 30px;margin-left: 10px;" href="index.php"><img style="width: 40px;height: 40px;" src="image/nav.jpg" alt=""></a>
                    <ul class="navbar-nav">

                    <form class="form-inline my-2 my-lg-0">
                      <input class="form-control mr-sm-2" type="text" name="search" placeholder="Search">
                      <button class="btn btn-success my-2 my-sm-0" type="button">Search</button>
                    </form>

                      <li style="margin-left:30px">
                        <a class="nav-link text-light" href="index.php">SẢN PHẨM</a>
                      </li>
                      <li style="margin-left:30px">
                        <a class="nav-link text-light" href="./introduce.php">GIỚI THIỆU</a>
                      </li>
                      <li style="margin-left:30px">
                        <a class="nav-link text-light" href="contact.php">LIÊN HỆ</a>
                      </li>               
                    </ul>
                    <div class="nav-item" style="margin-left:10px;width:210px;text-align:right">
                      <a class="nav-link text-light" href="#"><?php echo $_SESSION['profile']['name'] ?></a>
                        
                    </div>
                    <div  >
                      
                        <a class="nav-link text-light btn bg-success " href="logout.php">ĐĂNG XUẤT</a>
                    </div>
                
              
            <?php else: ?>
              <a style="margin-left: 10px;margin-right: 100px;" href="index.php"><img style="width: 40px;height: 40px;" src="image/nav.jpg" alt=""></a>
                    <ul class="navbar-nav">

                    <form class="form-inline my-2 my-lg-0" action="" style="margin-right:10px"  method="POST">
                      <input class="form-control mr-sm-2" type="text" name="search" placeholder="Search">
                      <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                    </form>

                      <li class="nav-item">
                        <a class="nav-link text-light" href="index.php">SẢN PHẨM</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-light" href="./introduce.php">GIỚI THIỆU</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-light" href="contact.php">LIÊN HỆ</a>
                      </li>               
                    </ul>
                    <div class="nav-item" style="margin-left: 107px;">
                        <a class="nav-link text-light btn bg-success " href="login.php">ĐĂNG NHẬP</a>
                    </div>
              <?php endif; ?>

              
            </nav>