<?php
include 'header.php';
?>


            <!-- body -->
             <!-- body -->
             <div id="body">
               
         
              <div id="product-info-body">
                <?php 

                  // $id =$_GET["id"];
                  // echo "ID: ".$id;

                  $data=file_get_contents("http://35.219.60.232/api.php/sanphams/".$_GET["id"]);
                  $data= json_decode($data, true);
                  

                  ?> 
            

                <!-- product-info-left -->
                  <div id="product-info-left">
                     <img  src=" <?php echo $data["hinhanh"]; ?> "/>
                  </div>


                  <!-- product-info-right -->
              
                  <div id="product-info-right">
                        <div id="product-info-right-name">
                            <h3 style="color: rgb(255, 81, 0);font-weight: bolder;"> <?php echo $data["tensp"]; ?>  </h3>
                            <h4 class="color-text"> <?php echo $data["dongia"]; ?> vnđ </h4>
                        </div>
          
                    
                        <div id="div-size">
                          <h5 id="content-color">-Màu:&nbsp;&nbsp;  <?php echo $data["mau"]; ?>     </h5>
                        </div>
                        <div id="div-size">
                          <h5 id="content-color">-Size:&nbsp;&nbsp;  <?php echo $data["size"]; ?>  </h5>
                        </div>
                        <div id="div-size">
                          <h5 id="content-color">-Thương hiệu:&nbsp;&nbsp;   <?php echo $data["thuonghieu"]; ?>     </h5>
                        </div>
                  
                      <div  id="content">
                        <h5 id="content-color">-Mô tả sản phẩm:</h5> 
                        <h5 id="content-text">   <?php echo $data["mota"]; ?>  </h5>
                      </div>
                    <a  href="order.php"><button id="btn-mua" class="btn btn-dark">Mua sản phẩm</button></a>
                    

                  </div>
                 
               
                    
              </div>
              <!--end info-->>
             
             
             

              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>

      </div>

    </body>
</html>