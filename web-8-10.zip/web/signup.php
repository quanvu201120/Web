﻿﻿<?php
include 'header.php';
?>

            <!-- body -->
             <!-- body -->
             <div id="body">
                <div  style="text-align: center; padding-top: 50px; height: 670px; width: 1100px; text-align: center;">
                    <form id="frmDangKy">
                        <h2 class="text-center text-danger">
                            SIGN UP
                        </h2>
                        <div class="row m-1 ">
                            <div class="col-4 col-md-3 text-right">Username</div>
                            <div class="col-8 col-md-9">
                                <input name="user" placeholder="Username"  class="form-control input-sign"  />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Password</div>
                            <div class="col-8 col-md-9">
                                <input name="pass" type="password"placeholder="Password"  class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Họ và tên</div>
                            <div class="col-8 col-md-9">
                                <input name="hoten" placeholder="Họ và tên" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Địa chỉ</div>
                            <div class="col-8 col-md-9">
                                <input name="diachi" placeholder="Địa chỉ" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Số diện thoại</div>
                            <div class="col-8 col-md-9">
                                <input name="sdt" type="number" placeholder="0123456789" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Email</div>
                            <div class="col-8 col-md-9">
                                <input name="email" placeholder="abc@gmail.com" class="form-control input-sign" />
                            </div>
                        </div>
                        <button id="signup-btn-sigup" style="width: 200px;" class="btn btn-dark">SIGN UP</button>
                    </form>
               
               </div>    

              </div>
              
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>

        <script>
            //Bước 1: Định nghĩa hàm
            function checkGmail(value, element) {
                let pattern = /^[0-9]*[a-z]*[0-9]*[a-z]*[0-9]*[a-z]*@gmail.com$/i;
                return this.optional(element) || pattern.test(value);
            }
            $(function () {
                //Bước 2: gắn hàm kiểm tra vào jquery validation
                $.validator.addMethod("gmail", checkGmail, "Chưa đúng định dạng Gmail");
    
                $("#frmDangKy").validate({
                    rules: {
                        user: { required: true,minlength:6,maxlength:20 },
                        pass: {required: true ,minlength:6,maxlength:20 },
                        hoten: { required: true},
                        diachi: { required: true},
                        sdt:{required:true},
                        email:{ required: true, gmail: true},
                        
                    },
                    messages: {
                       
                        
                        user: { required: "Vui lòng nhập thông tin" ,minlength:"Tối thiểu 6 ký tự",maxlength:"Không vượt quá 20 ký tự"},
                        pass: {required: "Vui lòng nhập thông tin" ,minlength:"Tối thiểu 6 ký tự",maxlength:"Không vượt quá 20 ký tự"},
                        hoten: { required: "Vui lòng nhập thông tin"},
                        diachi: { required: "Vui lòng nhập thông tin"},
                        sdt:{required:"Vui lòng nhập thông tin"},
                        email:{required: "Vui lòng nhập thông tin", gmail:"Định dạng xxxx@gmail.com"},
                    }
                });
            });
        </script>

    </body>
</html>