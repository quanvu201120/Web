﻿﻿<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href=" css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src=" https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.js"></script>
        <script src="https://cdn.ckeditor.com/ckeditor5/18.0.0/classic/ckeditor.js"></script>
    </head>
    <style>
       


        label.error {
            color: red;
        }

        .ck-editor__editable_inline {
            min-height: 200px;
        }
    </style>
    <body>
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                
                <a href="index.php"><img id="icon-nav" src="image/nav.jpg" alt=""></a>
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                <div class="nav-item" style="margin-left: 240px;">
                    <a class="nav-link text-light btn bg-warning" href=" login.php">ĐĂNG NHẬP</a>
                </div>
            </nav>

            <!-- body -->
             <!-- body -->
             <div id="body">
                <div  style="text-align: center; padding-top: 80px; height: 670px; width: 1100px; text-align: center;">
                    <form id="frmDangKy">
                        <h2 class="text-center text-danger">
                            SIGN UP
                        </h2>
                        <div class="row m-1 ">
                            <div class="col-4 col-md-3 text-right">Username</div>
                            <div class="col-8 col-md-9">
                                <input name="user" placeholder="Username"  class="form-control input-sign"  />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Password</div>
                            <div class="col-8 col-md-9">
                                <input name="pass" type="password"placeholder="Password"  class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Họ và tên</div>
                            <div class="col-8 col-md-9">
                                <input name="hoten" placeholder="Họ và tên" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Số diện thoại</div>
                            <div class="col-8 col-md-9">
                                <input name="sdt" type="number" placeholder="0123456789" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Email</div>
                            <div class="col-8 col-md-9">
                                <input name="email" placeholder="abc@gmail.com" class="form-control input-sign" />
                            </div>
                        </div>
                        <button id="signup-btn-sigup" style="width: 200px;" class="btn btn-dark">SIGN UP</button>
                    </form>
               
               </div>    

              </div>
              
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>

        <script>
            //Bước 1: Định nghĩa hàm
            function checkGmail(value, element) {
                let pattern = /^[0-9]*[a-z]*[0-9]*[a-z]*[0-9]*[a-z]*@gmail.com$/i;
                return this.optional(element) || pattern.test(value);
            }
            $(function () {
                //Bước 2: gắn hàm kiểm tra vào jquery validation
                $.validator.addMethod("gmail", checkGmail, "Chưa đúng định dạng Gmail");
    
                $("#frmDangKy").validate({
                    rules: {
                        user: { required: true,minlength:6 },
                        pass: {required: true ,minlength:6 },
                        hoten: { required: true},
                        sdt:{required:true},
                        email:{ required: true, gmail: true},
                        
                    },
                    messages: {
                       
                        
                        user: { required: "Vui lòng nhập thông tin" ,minlength:"Tối thiểu 6 ký tự"},
                        pass: {required: "Vui lòng nhập thông tin" ,minlength:"Tối thiểu 6 ký tự"},
                        hoten: { required: "Vui lòng nhập thông tin"},
                        sdt:{required:"Vui lòng nhập thông tin"},
                        email:{required: "Vui lòng nhập thông tin", gmail:"Định dạng xxxx@gmail.com"},
                    }
                });
            });
        </script>

    </body>
</html>