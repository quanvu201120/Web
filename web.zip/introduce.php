<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href=" css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                
                <a href="index.php"><img id="icon-nav" src="image/nav.jpg" alt=""></a>
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                <div class="nav-item" style="margin-left: 240px;">
                    <a class="nav-link text-light btn bg-warning" href=" login.php">ĐĂNG NHẬP</a>
                </div>
            </nav>

            <!-- body -->
             <!-- body -->
             <div id="body">
                 <br>
                <!-- introduce-nav -->
                <div id="introduce-nav">
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/xe.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href=" delivery.php"><h5 style="color:black">Giao hàng toàn quốc</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/money.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href=" pay.php"><h5 style="color:black">Thanh toán khi nhận hàng</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/tra.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a  href=" return.php"><h5 style="color:black">Đổi trả trong vòng 7 ngày</h5></a>
                        </div>
                    </div>
                </div>

                <!-- Nội dung -->
                <div>
                    <div>
                       <br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <!-- <strong>&nbsp;</strong> -->
                            <b style="font-size: 16pt;">B</b>ắt đầu hoạt động từ năm 2011, từ một cửa hàng chuyên nhập quần áo Hong Kong gốc, đến nay, cửa hàng đã có 3 chi nhánh tại Hà Nội, Đà Nẵng và Tp.HCM với vị thế là một nơi sản xuất đầm thiết kế và nhập khẩu hàng Quảng Châu chất lượng và uy tín trong cả nước.
                        </span>
                        <br><br>
                        
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <!-- <strong>&nbsp;</strong> -->
                            <b style="font-size: 16pt;">T</b>ồn tại và phát triển ngày càng vững mạnh suốt hơn 5 năm qua với số lượng khách hàng mới cũng như khách hàng thân thiết ngày càng tăng là minh chứng sống và và chắc chắn nhất cho chất lượng và niềm tin chúng tôi LUÔN ĐẢM BẢO:
                        </span>
                        <br><br>

                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>1.&nbsp;</strong>
                            Vải là yếu tố quan trọng quyết định 80% trang phục đẹp hay xấu. Vì vậy chọn lọc chất liệu là yếu tố chúng tôi luôn quan tâm hàng đầu. 80% là loại vải nhập có độ đàn hồi và dễ mặc, form chuẩn và thuận tiện không cần phải ủi quá nhiều. Chúng tôi luôn sản xuất từ các loại vải thời trang với giá thành tương đối không pha tạp vải may hàng chợ.
                        </span>
                        <br><br>
                        
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>2.&nbsp;</strong>
                            Sản phẩm nhập Hong Kong luôn được kiểm tra mẫu mã và chất lượng trước, nếu hàng đạt chất lượng sẽ nhập lô hàng về cho khách; nếu hàng không đạt chất lượng, sẽ không nhập hàng và không bán mẫu đó cho khách.
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>3.&nbsp;</strong>
                            Khoảng 5000 hàng mỗi tháng là con số nhỏ nhất của đối với mật độ tiêu dùng và mức độ tin tưởng của khách hàng Việt Nam giành cho shop.
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>4.&nbsp;</strong>
                            Cam kết chất lượng và uy tín bằng chính sách GIAO HÀNG THU TIỀN và chính sách ĐỔI TRẢ DỄ DÀNG cho khách.
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>5.&nbsp;</strong>
                            Quý khách có thể đặt câu hỏi với người bán hàng để kiểm tra tính chuyên nghiệp của họ khi chào bán sản phẩm thời trang may mặc tới bạn.
                        </span>
                        <br>
                        <hr><hr>

                    </div>
                </div>

            </div>  
              <!-- footer -->
            <div >
                <img id="footer" src=" image/footer.jpg" alt="">
                
            </div>
  
        </div>
    </body>
</html>