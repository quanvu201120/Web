<?php
    include 'connect.php';
    $sql="SELECT * FROM sanpham";
    $query = mysqli_query($conn,$sql);

    $total_row = mysqli_num_rows($query);
    // echo $total_row;
    // $row = mysqli_fetch_array($query);
    // echo $row['tensp']
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
       
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                
              <a href="index.php"><img id="icon-nav" src="image/nav.jpg" alt=""></a>
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href="index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href="./introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href="contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                <div class="nav-item" style="margin-left: 240px;">
                    <a class="nav-link text-light btn bg-warning" href="login.php">ĐĂNG NHẬP</a>
                </div>
            </nav>

            <!-- body -->
             <!-- body -->
             <div id="body">
                <!-- left -->
                  <div id="body-left">
                    
                  
                      <table >
                        <tr>
                          <td class="bg-dark text-center"><a class="nav-link text-light" href="#">Thun</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light" href="#">Sơ mi</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light" href="#">Couple</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light" href="#">Áo khoác</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light" href="#">Thể thao</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light" href="#">Phụ kiện</a></td>
                        </tr>
                      </table>
                      
                      <a style="margin-top: 10px;" href="order.php"><img style="width: 200px; height: 110px;" src="image/cart-icon.png" alt=""></a>
                </div>
                  <!-- right -->
                  <div id="body-right">
                    
                  <?php
                     while($row = mysqli_fetch_array($query)){     
                  ?>

                    <!-- product -->
                    <div id="product">
                      <div >
                        <a href="product-info.php">

                          <img src="<?php echo $row['hinhanh'] ?>" id="product-image"alt="">
                       
                        </a>
                      </div>
  
                      <div id="product-name-div">
                        <a id="product-name" href="product-info.php">
                          <h5 style="color:black ;" >

                            <?php echo $row['tensp'] ?>

                          </h5>
                        </a>
                    
                      </div>
                      <div>
                        <img id="product-icon" src="image/new.png" alt="">
                      </div>
                      <div id="price">                     

                      <?php echo $row['giagoc']." vnđ" ?>

                      </div>
                    </div>

                    <?php
                     }
                    ?>
                    
                
                    
                  </div>
              </div>
              
              <!-- footer -->
            <div >
              
                <img id="footer" src="image/footer.jpg" alt="">
              </div>
  
        </div>
    </body>
</html>