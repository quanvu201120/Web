<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        
    </head>
    <body>      
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                <a href="index.php"><img id="icon-nav" src="image/nav.jpg" alt=""></a>
                
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href="index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href="introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href="contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                <div class="nav-item" style="margin-left: 240px;">
                  <a class="nav-link text-light btn bg-warning" href="login.php">ĐĂNG NHẬP</a>
              </div>
            </nav>
            
                
                <div >
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.6511050549!2d106.68001951472597!3d10.76134939233174!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752f1b888ab357%3A0xc469f6e800231314!2zMjgwIEFuIEQuIFbGsMahbmcsIFBoxrDhu51uZyA0LCBRdeG6rW4gNSwgVGjDoG5oIHBo4buRIEjhu5MgQ2jDrSBNaW5oLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1600412484926!5m2!1svi!2s" width="1000" height="500px" frameborder="0" style="border:0; margin-top: 40px; margin-left: 50px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
               
                  <div style="border-radius: 10px; margin-top: 15px; margin-left: 90px; margin-bottom: 25px; height:100px; ">
                    <div class="contact">
                      <span > <b >HÀ NỘI</b><br>
                        195 Cầu Giấy,quận Cầu Giấy, Hà Nội 
                       <br> 024 6260 1370
                      </span>
                    </div>
                    <div class="contact">
                      <span><b>TP.HCM</b> <br>
                        280 An Dương Vương,quận 5, Tp.HCM 
                        <br> 024 6260 1370
                      </span>
                    </div>
                    <div class="contact">
                      <span><b>ĐÀ NẴNG</b><br>
                        372 Hùng Vương, Đà Nẵng
                        <br>0122 4464 030 
                      </span>
                    </div>
                </div>
                 <!-- footer -->
            <div >
              <img id="footer" src="image/footer.jpg" alt="">
              
          </div>
        </div>
    </body>
</html>