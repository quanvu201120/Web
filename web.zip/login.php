
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href=" css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src=" https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.js"></script>
      </head>
      <style>
        .loi{
          border:1px solid red;
        }
      </style>
    <body>
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                
                <a href="index.php">
                  <img id="icon-nav" src="image/nav.jpg" alt="">
                </a>
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                
            </nav>

            <!-- body -->
             <!-- body -->
             <div id="body" >
                 <div  style="text-align: center; padding-top: 80px; height: 670px; width: 1100px;" class="bg-dark">
                     <div id="login">
                        <form id="form-login" action="index.php" method="GET">
                            <h2 style="margin-top: 50px;">ĐĂNG NHẬP</h2>
                            <div id="enter">
                                <img src=" image/user.PNG">
                                <input id="login-user" type="text" placeholder="Username" name='name'>
                            </div>
                            <div id="enter">
                                <img src=" image/pass.PNG">
                                <input id="login-pass" type="password" name="pass" placeholder="Password" >
                            </div>
                                    
                            <button type='submit' id="btn-login">Đăng nhập</button><br>

                        </form>
                        <div  style="width: 320px;height: 30px;margin-left: auto;margin-right: auto; margin-top: 10px; ">
                          <h7 id="error" style="font-weight: bold;color: red;"></h7>
                        </div>
                        
                    </div>
                    <h6 style="color:white;">Chưa có tài khoản? <a href=" signup.php">Đăng ký ngay</a></h6>
                     
                </div>    
              </div>
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        
      </div>
      <script>

        function check(ele){
                    if(ele.val()==""){
                      return true;
                    }
                    return false;
                  }

        $(function(){
          
          $("#btn-login").click(function(){
            var user = $("#login-user");
            var pass = $("#login-pass");

            if(check(user) || check(pass)){
              $("#error").html("Vui lòng nhập đầy đủ thông tin");
              return;
            }

            if( user.val().length<6 || pass.val().length<6 ){
              $("#error").html("Username/password tối thiểu 6 ký tự");
              return;
            }
          });
        });

        $(function () {

                $("#form-login").validate({
                    rules: {
                        name: { required: true,minlength:6 },
                        pass: {required: true ,minlength:6 },
  
                    },
                    messages: {
                      name: { required: "",minlength:"" },
                        pass: {required: "" ,minlength:"" },
                      
                    }
                });
            });

      </script>
  </body>
</html>