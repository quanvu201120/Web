<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href=" css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                
              <a href="index.php"><img id="icon-nav" src="image/nav.jpg" alt=""></a>
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                <div class="nav-item" style="margin-left: 240px;">
                  <a class="nav-link text-light btn bg-warning" href=" login.php">ĐĂNG NHẬP</a>
              </div>
            </nav>

            <!-- body -->
             <!-- body -->
             <div id="body">
                <div id="order">
                    <div id="order-left">
                        <input class="form-group form-control"  placeholder="Họ và tên" type="text">
                        <input class="form-group form-control"  placeholder="Số điện thoại" type="number">
                        <input class="form-group form-control"  placeholder="Địa chỉ" type="text">
                        <textarea class="form-group form-control" placeholder="Ghi chú" name="" id="" cols="80" rows="5"></textarea>
                        <div  class="form-group form-control">
                            <input   type="radio" id="male" name="thanhtoan" value="01">
                            <label style="margin-right: 10px;" for="01">Thanh toán khi nhận hàng</label>
                            <input type="radio" id="female" name="thanhtoan" value="02">                            
                            <label for="02">chuyển khoản trước</label>
                        </div>
                    </div>
                    <div id="order-right">
                      
                    </div>
                     <button class="btn btn-dark" id="confirm">Đặt hàng</button>
                </div>
               
              </div>
              
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>
    </body>
</html>