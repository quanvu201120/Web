<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href=" css.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
                
              <a href="index.php"><img id="icon-nav" src="image/nav.jpg" alt=""></a>
                

                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" index.php">SẢN PHẨM</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" introduce.php">GIỚI THIỆU</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-light" href=" contact.php">LIÊN HỆ</a>
                  </li>
                
                </ul>
                <div class="nav-item" style="margin-left: 240px;">
                  <a class="nav-link text-light btn bg-warning" href=" login.php">ĐĂNG NHẬP</a>
              </div>
            </nav>

            <!-- body -->
             <!-- body -->
             <div id="body">
                
              <div id="product-info-body">
                <!-- product-info-left -->
                  <div id="product-info-left">
                    <img  src=" image/aaaaaaa.jpg" alt="photo">
                  </div>


                  <!-- product-info-right -->
                  <div id="product-info-right">
                    <div id="product-info-right-name">
                        <h2 style="color: rgb(255, 81, 0);font-weight: bolder;">Áo thun abc xyz abc xyz abc xyz</h2>
                        <h3>12.000.000.000Đ</h3>
                    </div>
                    <div id="product-info-right-description">
                      <h5>
                        Hiện nay trên thị trường có rất nhiều sản phẩm cùng loại nhưng chất liệu lại khác nhau hoàn toàn. Khách hàng cân nhắc trước khi đặt hàng tại shop khác. -Shop mình đặt uy tín lên hàng đầu, bán hàng đẹp không bán hàng xấu, ảnh như thế nào sản phẩm như vậy. tất cả các mặt hàng tại shop đều tự chụp ,tự quay video nên các bạn yên tâm ảnh như thế nào hàng như thế ấy. Áo thun nam cực đẹp sản phẩm hàng Việt Nam đẹp từ đường may mũi chỉ nhé Áo thun nam giá rẻ. áo thun nam body. Áo phông nam cao cấp. Áo thun nam dày mịn . Áo thun nam tay dài body.
                      </h5>
                    </div>
                    
                      <a class="text-light btn btn-dark add"href=" order.php">Thêm vào giỏ hàng</a>
                    
                  </div>
              </div>
                  

              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>

      </div>

    </body>
</html>