﻿﻿<?php
      session_start();
      include_once("call_api.php");


      if(isset($_POST['search'])){
        $search = $_POST['search'];
        $_SESSION['timkiem']=$_POST;
        
        if(!empty($search)){ 
          header('location: search.php');
        }
      }
      if(isset($_POST["Submit"])){

        $data_array =  array(
        "username"        => $_POST["username"],
        "hoten"        => $_POST["hoten"],
        "password"        => $_POST["password"],
        "mail"        => $_POST["mail"],
        "phone"        => $_POST["phone"],
        "address"        => $_POST["address"],
                    
        );
        $make_call = post('http://35.219.60.232/api.php/users', $data_array);
        header('location: login.php');
        
                    
    }
      
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css.css">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.22/b-1.6.4/fh-3.1.7/r-2.2.6/sp-1.2.0/datatables.min.css"/>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> 
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> 
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script> 
       
        <script src=" https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
        <script>
            $(document).ready(function() {
                $('#example').DataTable();
            } );    
        </script>
        <script>
             function isNumberKey(evt){
                                var charCode = (evt.which) ? evt.which : event.keyCode
                                if (charCode > 31 && (charCode < 48 || charCode > 57))
                                    return false;
                                return true;
                            }
        </script>

    </head>
    <style>

          .bold:hover{
            font-weight:bolder;
          }
          #login-order:hover{
            color: rgb(153, 255, 0);
            font-size: 41px;

          }
           
          #btn-mua{
            
            width:500px;
            height:50px ; 
            margin-top:10px;
            margin-left:75px

          }
         
          label.error {
            color: red;
          }

          .ck-editor__editable_inline {
              min-height: 200px;
          }
            #content{
              
              width: 600px;
              height: 160px;
              word-wrap: break-word;
          
          }
          #content p{
            font-size: 20px;
          
          }
          #content-text {
            margin-left:10px ;
          }
          #div-size{
          height: 40px;
          width: 600px;
          
          
        }   
        #content-color{
          color: rgb(16, 134, 238);
          display: inline-block;
        }
        .color-text{
          color: rgb(16, 134, 238);
        }

    </style>
    <body>
       
        <div id="box">
            <!-- nav -->
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
            <?php if( isset($_SESSION['profile'])) : ?>
    
              <a style="margin-right: 70px;margin-left: 20px;" href="index.php"><img style="width: 40px;height: 40px;" src="image/nav.jpg" alt=""></a>
                    <ul class="navbar-nav">

                    <form class="form-inline my-2 my-lg-0" action="" method="POST">
                      <input class="form-control mr-sm-2" type="text" name="search" placeholder="Search">
                      <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                    </form>

                      <li style="margin-left:30px">
                        <a class="nav-link text-light" href="index.php">SẢN PHẨM</a>
                      </li>
                      <li style="margin-left:30px">
                        <a class="nav-link text-light" href="./introduce.php">GIỚI THIỆU</a>
                      </li>
                      <li style="margin-left:30px">
                        <a class="nav-link text-light" href="contact.php">LIÊN HỆ</a>
                      </li>
                      
                      <li class="dropdown" style="margin-left:70px;width:210px;">
                            <a align="center" class="nav-link dropdown-toggle text-light bold" href="#" id="navbardrop" data-toggle="dropdown">
                            <?php echo $_SESSION['profile']['name'] ?>
                            </a>
                            <div class="dropdown-menu" style="background-color: #ac1ffd; text-align:center">
                              <a  style="width:210px; " class="dropdown-item bg-danger text-light bold" href="#">Thông tin cá nhân</a>
                              <a  style="width:210px; " class="dropdown-item bg-primary text-light bold" href="#">Lịch sử đơn hàng</a>
                              <a  style="width:210px; " class="dropdown-item bg-warning text-light bold" href="logout.php">Đăng xuất</a>
                          
                            </div>
                      </li>

                    </ul>

    
            <?php else: ?>
              <a style="margin-left: 20px;margin-right: 90px;" href="index.php"><img style="width: 40px;height: 40px;" src="image/nav.jpg" alt=""></a>
                    <ul class="navbar-nav">

                    <form class="form-inline my-2 my-lg-0"  style="margin-right:10px" action="" method="POST">
                      <input class="form-control mr-sm-2" type="text" name="search" placeholder="Search">
                      <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                    </form>

                      <li class="nav-item">
                        <a class="nav-link text-light" href="index.php">SẢN PHẨM</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-light" href="./introduce.php">GIỚI THIỆU</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-light" href="contact.php">LIÊN HỆ</a>
                      </li>               
                    </ul>
                    <div class="nav-item" style="margin-left: 90px;">
                        <a class="nav-link text-light btn bg-success " href="login.php">ĐĂNG NHẬP</a>
                    </div>
              <?php endif; ?>

              
            </nav>
<?php if( isset($_SESSION['profile'])) : ?>
            <div style="height:700px;padding-top:200px;text-align:center;">
                <div  style="height:100px;border: 5px dashed black; border-radius: 100px;text-align:center;padding-top:18px">
                    <h1 style="color:red;">Bạn không thể sử dụng tính năng này</h1>
                </div>
                
            </div>
  <?php else: ?>
            
            <!-- body -->
             <!-- body -->
             <div id="body">
                <div  style="text-align: center; padding-top: 50px; height: 670px; width: 1100px; text-align: center;">
                <form id="frmDangKy" action="" method="POST">
                        <h2 class="text-center text-danger">
                            SIGN UP
                        </h2>
                        <div class="row m-1 ">
                            <div class="col-4 col-md-3 text-right">Username</div>
                            <div class="col-8 col-md-9">
                                <input name="username" placeholder="Username"  class="form-control input-sign"  />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Password</div>
                            <div class="col-8 col-md-9">
                                <input name="password" type="password"placeholder="Password"  class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Họ và tên</div>
                            <div class="col-8 col-md-9">
                                <input name="hoten" placeholder="Họ và tên" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Địa chỉ</div>
                            <div class="col-8 col-md-9">
                                <input name="address" placeholder="Địa chỉ" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Số diện thoại</div>
                            <div class="col-8 col-md-9">
                                <input name="phone" type="number" placeholder="0123456789" class="form-control input-sign" />
                            </div>
                        </div>
                        <div class="row m-1">
                            <div class="col-4 col-md-3 text-right">Email</div>
                            <div class="col-8 col-md-9">
                                <input name="mail" placeholder="abc@gmail.com" class="form-control input-sign" />
                            </div>
                        </div>
                        <button id="signup-btn-sigup" name='Submit' style="width: 200px;" class="btn btn-dark">SIGN UP</button>
                    </form>
               
               </div>    

              </div>
<?php endif; ?>
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        </div>

        <script>
            
            function checkGmail(value, element) {
                let pattern = /^[0-9]*[a-z]*[0-9]*[a-z]*[0-9]*[a-z]*@gmail.com$/i;
                return this.optional(element) || pattern.test(value);
            }
            $(function () {
               
                $.validator.addMethod("gmail", checkGmail, "Chưa đúng định dạng Gmail");
    
                $("#frmDangKy").validate({
                    rules: {
                        username: { required: true,minlength:6,maxlength:20 },
                        password: {required: true ,minlength:6,maxlength:20 },
                        hoten: { required: true},
                        address: { required: true},
                        phone:{required:true},
                        mail:{ required: true, gmail: true},
                        
                    },
                    messages: {
                       
                        
                        username: { required: "Vui lòng nhập thông tin" ,minlength:"Tối thiểu 6 ký tự",maxlength:"Không vượt quá 20 ký tự"},
                        password: {required: "Vui lòng nhập thông tin" ,minlength:"Tối thiểu 6 ký tự",maxlength:"Không vượt quá 20 ký tự"},
                        hoten: { required: "Vui lòng nhập thông tin"},
                        address: { required: "Vui lòng nhập thông tin"},
                        phone:{required:"Vui lòng nhập thông tin"},
                        mail:{required: "Vui lòng nhập thông tin", gmail:"Định dạng xxxx@gmail.com"},
                    }
                });
            });
        </script>

    </body>
</html>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }

</script>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    } 
</script>

