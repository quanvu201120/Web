<?php
include 'header.php';
?>


            <!-- body -->
             <!-- body -->
             <div id="body">
                <!-- left -->
                <div id="body-left">  
                   
                 
                  <table >  

                    <br><br><br>
                        <tr>
                          <td class="bg-dark text-center"><a class="nav-link text-light bold" href="">Thông tin tài khoản</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold" data-toggle='modal' data-target='#editUser'  href="#">Chỉnh sửa thông tin</a></td>
                        </tr>
                        <tr>
                          <td class="bg-dark  text-center"><a class="nav-link text-light bold"  data-toggle='modal' data-target='#deleteUser' href="#">Xóa tài khoản</a></td>
                        </tr>
                        
                      </table>
                       
                       
                </div>
                  <!-- right -->
                <div id="body-right-user" >
                    <br><br>
                    <h2 align="center" style="color:blue;">Thông tin tài khoản</h2>
                    <div style="height:600px; padding-left:100px">
                    
                    
                        <table >
                            <tr >
                                <th style="width:150px">Username</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </td>
                            </tr>
                            <tr>
                                <th>Password</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</td>
                            </tr>
                            <tr>
                                <th>Họ tên</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </td>
                            </tr>
                            <tr>
                                <th>Số diện thoại</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </td>
                            </tr>
                            <tr>
                                <th>Địa chỉ</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </td>
                            </tr>
                            <tr>
                                <th>Level</th>
                                <td> xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </td>
                            </tr>
                        
                        </table>

                    </div>
                 

                </div>
              
              <!-- footer -->
            <div >
              
                <img id="footer" src="image/footer.jpg" alt="">
              </div>
  
        </div>
    </body>

    <div class="modal" id="editUser">
        <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 style="margin-left:120px" class="modal-title">Chỉnh sửa thông tin</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <form action="" method="POST" enctype="multipart/form-data">
        <table >
                            <tr >
                                <th style="width:150px">Password</th>
                                <td><input name="password" type="password"placeholder="Password"  class="form-control input-sign" /></td>
                            </tr>
                            
                            <tr>
                                <th>Họ tên</th>
                                <td> <input name="hoten" placeholder="Họ và tên" class="form-control input-sign" /> </td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td> <input name="mail" placeholder="abc@gmail.com" class="form-control input-sign" /> </td>
                            </tr>
                            <tr>
                                <th>Số diện thoại</th>
                                <td> <input name="phone" type="number" placeholder="0123456789" class="form-control input-sign" /> </td>
                            </tr>
                            <tr>
                                <th>Địa chỉ</th>
                                <td> <input name="address" placeholder="Địa chỉ" class="form-control input-sign" /> </td>
                            </tr>
                           
                        
                        </table>
            <div class="modal-footer" align="center" style="margin-top:20px">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type='submit'  name='edit-user' class='btn btn btn-danger' value='Confirm' />
            </div>
        </form>
        </div>
        
        
      </div>
    </div>
  </div>

    <div class="modal" id="deleteUser">
        <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 style="margin-left:160px" class="modal-title">Xóa tài khoản</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        <form action="" method="POST" enctype="multipart/form-data">
                        <table >
                            <tr >
                                <th>Xác nhận xóa tài khoản:</th>
                                
                            </tr>
                        </table>
            <div class="modal-footer" align="center" style="margin-top:20px">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type='submit'  name='edit-user' class='btn btn btn-danger' value='Confirm' />
            </div>
        </form>
        </div>
        
        
      </div>
    </div>
  </div>

  

</html>