﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'sr', {
	alertUrl: 'Унесите УРЛ слике',
	alt: 'Алтернативни текст',
	border: 'Оквир',
	btnUpload: 'Пошаљи на сервер',
	button2Img: 'Да ли желите да промените одабрану слику дугмета као једноставну слику?',
	hSpace: 'HSpace',
	img2Button: 'Да ли желите да промените одабрану слику у слику дугмета?',
	infoTab: 'Инфо слике',
	linkTab: 'Линк',
	lockRatio: 'Закључај однос',
	menu: 'Особине слика',
	resetSize: 'Ресетуј величину',
	title: 'Особине слика',
	titleButton: 'Особине дугмета са сликом',
	upload: 'Пошаљи',
	urlMissing: 'Недостаје УРЛ слике.',
	vSpace: 'VSpace',
	validateBorder: 'Ивица треба да буде цифра.',
	validateHSpace: 'HSpace треба да буде цифра.',
	validateVSpace: 'VSpace треба да буде цифра.'
} );
